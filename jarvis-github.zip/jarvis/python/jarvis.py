"""
Jarvis - Personal AI Assistant (Python CLI)
Run: python jarvis.py
Requires: pip install anthropic requests beautifulsoup4 yfinance
"""

import os
import json
import re
import sys
import anthropic
import requests
from datetime import datetime

try:
    import yfinance as yf
    YFINANCE_AVAILABLE = True
except ImportError:
    YFINANCE_AVAILABLE = False
    print("Note: yfinance not installed. Stock features limited. Run: pip install yfinance")

try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False
    print("Note: beautifulsoup4 not installed. Web search limited. Run: pip install beautifulsoup4")

# ── Config ───────────────────────────────────────────────────────────────────
MEMORY_FILE  = "jarvis_memory.json"
HISTORY_FILE = "jarvis_history.json"
API_KEY      = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL        = "claude-sonnet-4-20250514"

if not API_KEY:
    print("\n⚠  ANTHROPIC_API_KEY not set.")
    print("   Set it with:  export ANTHROPIC_API_KEY=sk-ant-...")
    print("   Or edit jarvis.py and paste it into API_KEY directly.\n")

client = anthropic.Anthropic(api_key=API_KEY) if API_KEY else None

# ── Persistence ───────────────────────────────────────────────────────────────
def load_json(path, default):
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return default

def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

# ── Stock module ──────────────────────────────────────────────────────────────
def get_stock_info(symbol: str) -> str:
    if not YFINANCE_AVAILABLE:
        return f"yfinance not installed. Run: pip install yfinance"
    try:
        ticker = yf.Ticker(symbol.upper())
        info   = ticker.info
        name        = info.get("longName", symbol)
        price       = info.get("currentPrice") or info.get("regularMarketPrice", "N/A")
        prev_close  = info.get("previousClose", None)
        market_cap  = info.get("marketCap", "N/A")
        pe          = info.get("trailingPE", "N/A")
        week_high   = info.get("fiftyTwoWeekHigh", "N/A")
        week_low    = info.get("fiftyTwoWeekLow", "N/A")
        analyst     = info.get("recommendationKey", "N/A").upper()
        summary     = (info.get("longBusinessSummary") or "")[:400]

        change_str = "N/A"
        if isinstance(price, (int, float)) and isinstance(prev_close, (int, float)) and prev_close:
            change = (price - prev_close) / prev_close * 100
            change_str = f"{change:+.2f}%"

        cap_str = f"${market_cap:,}" if isinstance(market_cap, int) else str(market_cap)

        return (
            f"=== {symbol.upper()} — {name} ===\n"
            f"Price     : ${price}  ({change_str})\n"
            f"52w range : ${week_low} – ${week_high}\n"
            f"Mkt cap   : {cap_str}\n"
            f"P/E ratio : {pe}\n"
            f"Analyst   : {analyst}\n"
            f"About     : {summary}..."
        )
    except Exception as e:
        return f"Could not fetch data for '{symbol}': {e}"

# ── Web search module ─────────────────────────────────────────────────────────
def web_search(query: str, max_results: int = 5) -> str:
    try:
        url     = f"https://html.duckduckgo.com/html/?q={requests.utils.quote(query)}"
        headers = {"User-Agent": "Mozilla/5.0 (compatible; JarvisBot/1.0)"}
        resp    = requests.get(url, headers=headers, timeout=10)

        if not BS4_AVAILABLE:
            return f"beautifulsoup4 not installed. Run: pip install beautifulsoup4"

        soup    = BeautifulSoup(resp.text, "html.parser")
        results = []
        for r in soup.select(".result__body")[:max_results]:
            title   = r.select_one(".result__title")
            snippet = r.select_one(".result__snippet")
            link    = r.select_one(".result__url")
            if title and snippet:
                results.append(
                    f"• {title.get_text(strip=True)}\n"
                    f"  {snippet.get_text(strip=True)}\n"
                    f"  {link.get_text(strip=True) if link else ''}"
                )
        return "\n\n".join(results) if results else "No results found."
    except Exception as e:
        return f"Search error: {e}"

# ── Fetch page content ────────────────────────────────────────────────────────
def fetch_page(url: str) -> str:
    try:
        headers = {"User-Agent": "Mozilla/5.0 (compatible; JarvisBot/1.0)"}
        resp    = requests.get(url, headers=headers, timeout=10)
        if BS4_AVAILABLE:
            soup = BeautifulSoup(resp.text, "html.parser")
            for tag in soup(["script", "style", "nav", "footer", "header"]):
                tag.decompose()
            return soup.get_text(separator=" ", strip=True)[:3000]
        return resp.text[:3000]
    except Exception as e:
        return f"Could not fetch page: {e}"

# ── Core AI chat ──────────────────────────────────────────────────────────────
SYSTEM_BASES = {
    "chat":   "You are Jarvis, a loyal, helpful AI assistant. Be concise but thorough. End with 'Is there anything else I can do for you, sir?' when appropriate.",
    "search": "You are Jarvis. Synthesize these web search results into a clear, well-organized answer. Cite sources where possible.",
    "stock":  "You are Jarvis providing stock analysis. Given live data, provide: technical outlook (bullish/bearish/neutral), key risks, and a short-term prediction. End with 'Prediction, not financial advice.'",
    "book":   "You are Jarvis. Summarize the book thoroughly: overview, author context, key themes, chapter highlights, key quotes, main takeaways.",
    "fetch":  "You are Jarvis. Summarize the key information from this webpage content for the user.",
}

def chat(user_input: str, memory: list, history: list, mode: str = "chat") -> str:
    if not client:
        return "Error: API key not set. Please set ANTHROPIC_API_KEY."

    mem_str = "\n".join(f"- {m}" for m in memory) if memory else "None saved."
    system  = SYSTEM_BASES.get(mode, SYSTEM_BASES["chat"])
    system += f"\n\nUser memory / preferences:\n{mem_str}"
    system += f"\n\nCurrent date: {datetime.now().strftime('%B %d, %Y')}"

    history.append({"role": "user", "content": user_input})
    if len(history) > 30:
        history[:] = history[-30:]

    try:
        response = client.messages.create(
            model=MODEL,
            max_tokens=1000,
            system=system,
            messages=history,
        )
        reply = response.content[0].text
        history.append({"role": "assistant", "content": reply})
        save_json(HISTORY_FILE, history)
        return reply
    except anthropic.AuthenticationError:
        return "Error: Invalid API key. Check your ANTHROPIC_API_KEY."
    except Exception as e:
        return f"API error: {e}"

# ── Command router ────────────────────────────────────────────────────────────
def handle(user_input: str, memory: list, history: list) -> str:
    raw   = user_input.strip()
    lower = raw.lower()

    # ── Memory commands ──
    if re.match(r"^(remember|save):", lower):
        item = re.sub(r"^(remember|save):\s*", "", raw, flags=re.I).strip()
        if item:
            memory.append(item)
            save_json(MEMORY_FILE, memory)
            return f'✓ Saved: "{item}"  (Total memories: {len(memory)})\nIs there anything else, sir?'
        return "Nothing to save — please add text after 'remember:'."

    if lower in ("show memory", "recall all", "list memory", "memory"):
        if not memory:
            return "No memories saved yet, sir."
        lines = "\n".join(f"  {i+1}. {m}" for i, m in enumerate(memory))
        return f"Your memories ({len(memory)}):\n{lines}"

    if re.match(r"^(forget|delete):", lower):
        item  = re.sub(r"^(forget|delete):\s*", "", raw, flags=re.I).strip()
        before = len(memory)
        memory[:] = [m for m in memory if item.lower() not in m.lower()]
        save_json(MEMORY_FILE, memory)
        removed = before - len(memory)
        return f"✓ Removed {removed} item(s) matching '{item}'." if removed else f"No memory matched '{item}'."

    if lower == "clear memory":
        memory.clear()
        save_json(MEMORY_FILE, memory)
        return "Memory cleared, sir."

    # ── Stock ──
    m = re.match(r"^(?:stock|stocks?|analyze)\s+(\w+)", lower) or re.match(r"^\[STOCK:\s*(\w+)\]", raw, re.I)
    if m:
        symbol = m.group(1).upper()
        print(f"  [Fetching {symbol} data...]")
        data = get_stock_info(symbol)
        return chat(f"Live data for {symbol}:\n\n{data}\n\nProvide analysis.", memory, history, mode="stock")

    # ── Web search ──
    m = re.match(r"^(?:search|find|look up)\s+(.+)", lower) or re.match(r"^\[SEARCH:\s*(.+)\]", raw, re.I)
    if m:
        query = m.group(1).strip().rstrip("]")
        print(f"  [Searching: {query}...]")
        results = web_search(query)
        return chat(f"Search results for '{query}':\n\n{results}\n\nSynthesize these.", memory, history, mode="search")

    # ── Book summary ──
    m = re.match(r"^(?:book(?:\s+summary)?|summarize book|summarize)\s+(.+)", lower) or re.match(r"^\[BOOK:\s*(.+)\]", raw, re.I)
    if m:
        title = m.group(1).strip().rstrip("]")
        print(f"  [Summarizing: {title}...]")
        return chat(f"Please give me a full, comprehensive summary of the book: '{title}'", memory, history, mode="book")

    # ── Fetch URL ──
    if re.match(r"https?://", lower):
        print(f"  [Fetching page...]")
        content = fetch_page(raw)
        return chat(f"Here is the page content:\n\n{content}\n\nSummarize the key information.", memory, history, mode="fetch")

    # ── Help ──
    if lower in ("help", "?", "commands"):
        return """
Commands:
  remember: <item>          Save to memory
  show memory               List all memories
  forget: <item>            Remove from memory
  clear memory              Wipe all memory
  stock <SYMBOL>            Stock analysis  (e.g. stock AAPL)
  search <query>            Web research
  book summary <title>      Full book summary
  https://...               Summarize any webpage
  help                      Show this list
  quit / exit               Exit Jarvis
  (anything else)           General AI chat
"""

    # ── Default chat ──
    return chat(raw, memory, history)

# ── Main REPL ─────────────────────────────────────────────────────────────────
def main():
    print("\n" + "="*52)
    print("  JARVIS — Personal AI Assistant")
    print("  Powered by Claude (Anthropic)")
    print("="*52)

    memory  = load_json(MEMORY_FILE, [])
    history = load_json(HISTORY_FILE, [])

    print(f"\n  Memories loaded : {len(memory)}")
    print(f"  History loaded  : {len(history)} messages")
    print(f"  API key         : {'✓ set' if API_KEY else '✗ missing'}")
    print(f"\n  Type 'help' for commands.\n")
    print("Jarvis: Hello, sir. I'm ready and at your service.\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nJarvis: Goodbye, sir.")
            sys.exit(0)

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "bye", "goodbye"):
            print("Jarvis: Goodbye, sir. Have a great day.")
            sys.exit(0)

        print("Jarvis: ", end="", flush=True)
        reply = handle(user_input, memory, history)
        print(reply)
        print()

if __name__ == "__main__":
    main()
