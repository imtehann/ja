# 🤖 Jarvis — Personal AI Assistant

A full-stack personal AI assistant powered by Claude. Includes a web app, Python CLI backend, and Chrome extension.

---

## 📁 Project Structure

```
jarvis/
├── web/                   # Standalone web app (open index.html in browser)
│   └── index.html
├── python/                # Python CLI backend
│   ├── jarvis.py
│   └── requirements.txt
├── chrome-extension/      # Chrome extension (sidebar assistant)
│   ├── manifest.json
│   ├── popup.html
│   ├── popup.js
│   ├── content.js
│   ├── background.js
│   └── icons/
│       ├── icon16.png     # (add your own icons)
│       ├── icon48.png
│       └── icon128.png
└── README.md
```

---

## ✨ Features

| Feature | Web | Python | Chrome |
|---|---|---|---|
| Chat (Claude AI) | ✅ | ✅ | ✅ |
| Web research | ✅ | ✅ | ✅ |
| Stock analysis | ✅ | ✅ | ✅ |
| Book summaries | ✅ | ✅ | ✅ |
| Memory (persistent) | ✅ | ✅ | ✅ |
| Page summarizer | ❌ | ❌ | ✅ |

---

## 🚀 Quick Start

### Web App
1. Open `web/index.html` in your browser
2. Enter your Anthropic API key
3. Start chatting

### Python CLI
```bash
cd python
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-your-key-here
python jarvis.py
```

### Chrome Extension
1. Open Chrome → `chrome://extensions`
2. Enable **Developer mode** (top right toggle)
3. Click **Load unpacked**
4. Select the `chrome-extension/` folder
5. Click the Jarvis icon in your toolbar
6. Enter your API key in Settings

---

## 🔑 Getting an API Key

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Sign up / log in
3. Go to **API Keys** → **Create Key**
4. Copy and paste it into Jarvis

> Your API key is stored locally and never sent anywhere except directly to Anthropic.

---

## 🛠️ Python Commands

```
remember: <item>         Save something to memory
show memory              List all memories
forget: <item>           Remove a memory
stock <SYMBOL>           Stock analysis (e.g. stock TSLA)
search <query>           Web research
book summary <title>     Full book summary
quit                     Exit
```

---

## 🧩 Chrome Extension Features

- **Sidebar chat** — talk to Jarvis on any webpage
- **Summarize page** — one-click summary of any article/page
- **Selected text** — right-click selected text → "Ask Jarvis"
- **Memory** — remembers your preferences across sessions

---

## 📦 Dependencies

### Python
- `anthropic` — Claude API
- `yfinance` — Stock data
- `requests` — HTTP
- `beautifulsoup4` — Web scraping

### Web / Chrome
- Vanilla JS, no frameworks needed
- Anthropic API via fetch

---

## 🤝 Contributing

Pull requests welcome! Please open an issue first to discuss changes.

---

## ⚠️ Disclaimer

Stock predictions are for informational purposes only. Not financial advice.

---

## 📄 License

MIT License — free to use, modify, and distribute.
