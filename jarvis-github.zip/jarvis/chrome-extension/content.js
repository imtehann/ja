// Jarvis Chrome Extension — content.js
// Runs on every page. Currently minimal — used for future page interaction features.

// Listen for messages from the extension
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_PAGE_TEXT") {
    const clone = document.cloneNode(true);
    clone.querySelectorAll("script,style,nav,footer,header,aside").forEach(el => el.remove());
    const text = (clone.body?.innerText || document.body.innerText || "").slice(0, 4000);
    sendResponse({ text, title: document.title, url: location.href });
  }
});
