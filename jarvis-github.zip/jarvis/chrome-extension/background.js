// Jarvis Chrome Extension — background.js (service worker)

// Create right-click context menu on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "jarvis-explain",
    title: "Ask Jarvis about this",
    contexts: ["selection"],
  });
  chrome.contextMenus.create({
    id: "jarvis-summarize",
    title: "Summarize this page with Jarvis",
    contexts: ["page"],
  });
});

// Handle right-click menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "jarvis-explain" && info.selectionText) {
    // Open popup and pass selected text
    chrome.action.openPopup().catch(() => {});
    // Small delay to let popup load, then send message
    setTimeout(() => {
      chrome.runtime.sendMessage({
        type: "SELECTED_TEXT",
        text: info.selectionText.slice(0, 500),
      });
    }, 400);
  }

  if (info.menuItemId === "jarvis-summarize") {
    chrome.action.openPopup().catch(() => {});
    setTimeout(() => {
      chrome.runtime.sendMessage({ type: "OPEN_SUMMARIZE" });
    }, 400);
  }
});
