// Jarvis Chrome Extension — popup.js

const MODEL = "claude-sonnet-4-20250514";

let apiKey = "";
let memory = [];
let chatHistory = [];
let currentMode = "chat";

const messagesEl   = document.getElementById("messages");
const inputEl      = document.getElementById("user-input");
const sendBtn      = document.getElementById("send-btn");

// ── Storage helpers ───────────────────────────────────────────────────────────
async function loadStorage() {
  return new Promise(resolve => {
    chrome.storage.local.get(["apiKey", "memory", "chatHistory"], data => {
      apiKey      = data.apiKey      || "";
      memory      = data.memory      || [];
      chatHistory = data.chatHistory || [];
      resolve();
    });
  });
}
function saveStorage() {
  chrome.storage.local.set({ apiKey, memory, chatHistory: chatHistory.slice(-30) });
}

// ── Tab switching ─────────────────────────────────────────────────────────────
document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById(tab.dataset.tab + "-view").classList.add("active");
    if (tab.dataset.tab === "memory") renderMemory();
  });
});

// ── Mode buttons ──────────────────────────────────────────────────────────────
document.querySelectorAll(".mode-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".mode-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    currentMode = btn.dataset.mode;
    const placeholders = {
      chat:   "Ask Jarvis anything...",
      search: "Search for...",
      stock:  "Stock symbol e.g. TSLA, AAPL...",
      book:   "Book title...",
    };
    inputEl.placeholder = placeholders[currentMode];
  });
});

// ── Chat UI helpers ───────────────────────────────────────────────────────────
function addMessage(role, text) {
  const div    = document.createElement("div");
  div.className = `msg ${role}`;
  const label  = document.createElement("div");
  label.className = "msg-label";
  label.textContent = role === "user" ? "YOU" : "JARVIS";
  const bubble = document.createElement("div");
  bubble.className = "msg-bubble";
  bubble.textContent = text;
  div.appendChild(label);
  div.appendChild(bubble);
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function showThinking() {
  const div = document.createElement("div");
  div.id = "thinking";
  div.innerHTML = "<span></span><span></span><span></span>";
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return div;
}

// ── System prompt builder ─────────────────────────────────────────────────────
function buildSystem(mode) {
  const memStr = memory.length ? memory.map(m => `- ${m}`).join("\n") : "None.";
  const bases = {
    chat:   "You are Jarvis, a loyal, helpful AI assistant. Be concise. End with 'Is there anything else I can do for you, sir?' when appropriate.",
    search: "You are Jarvis. Provide detailed, well-organized research on the topic as if you searched the web. Be thorough and cite likely sources.",
    stock:  "You are Jarvis providing stock analysis. Give: current context, news you know, technical outlook (bullish/bearish/neutral), key risks, short-term prediction. End with 'Prediction, not financial advice.'",
    book:   "You are Jarvis. Summarize the book: overview, author context, key themes, chapter highlights, key quotes, main takeaways.",
    page:   "You are Jarvis. Summarize the key information from this webpage for the user. Be concise but comprehensive.",
  };
  return (bases[mode] || bases.chat) + `\n\nUser memory:\n${memStr}`;
}

// ── Claude API call ───────────────────────────────────────────────────────────
async function callClaude(userText, mode, extraHistory) {
  if (!apiKey) return "Please set your API key in Settings first, sir.";

  const history = [...(extraHistory || chatHistory)];
  history.push({ role: "user", content: userText });

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1000,
      system: buildSystem(mode),
      messages: history.slice(-20),
    }),
  });

  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return data.content.map(b => b.text || "").join("");
}

// ── Send message ──────────────────────────────────────────────────────────────
async function sendMessage() {
  const text = inputEl.value.trim();
  if (!text) return;

  addMessage("user", text);
  inputEl.value = "";
  inputEl.style.height = "36px";
  sendBtn.disabled = true;

  const thinking = showThinking();

  try {
    chatHistory.push({ role: "user", content: text });
    const reply = await callClaude(text, currentMode, chatHistory);
    thinking.remove();
    chatHistory.push({ role: "assistant", content: reply });
    if (chatHistory.length > 30) chatHistory = chatHistory.slice(-30);
    saveStorage();
    addMessage("jarvis", reply);
  } catch (e) {
    thinking.remove();
    addMessage("jarvis", `Error: ${e.message}`);
  }

  sendBtn.disabled = false;
  inputEl.focus();
}

sendBtn.addEventListener("click", sendMessage);
inputEl.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});
inputEl.addEventListener("input", () => {
  inputEl.style.height = "36px";
  inputEl.style.height = Math.min(inputEl.scrollHeight, 100) + "px";
});

// ── Page summarizer ───────────────────────────────────────────────────────────
document.getElementById("summarize-btn").addEventListener("click", async () => {
  const btn = document.getElementById("summarize-btn");
  const out = document.getElementById("summary-output");
  const info = document.getElementById("page-info");

  btn.disabled = true;
  btn.textContent = "Summarizing...";
  out.textContent = "Reading page...";

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    info.textContent = `Page: ${tab.title || tab.url}`;

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const clone = document.cloneNode(true);
        clone.querySelectorAll("script,style,nav,footer,header,aside").forEach(el => el.remove());
        return (clone.body?.innerText || document.body.innerText || "").slice(0, 4000);
      },
    });

    const pageText = results[0]?.result || "";
    if (!pageText.trim()) { out.textContent = "Could not read this page."; return; }

    const summary = await callClaude(
      `Please summarize this webpage content:\n\n${pageText}`,
      "page",
      []
    );
    out.textContent = summary;
  } catch (e) {
    out.textContent = `Error: ${e.message}`;
  } finally {
    btn.disabled = false;
    btn.textContent = "Summarize this page";
  }
});

// ── Memory view ───────────────────────────────────────────────────────────────
function renderMemory() {
  const list = document.getElementById("memory-list");
  list.innerHTML = "";
  if (!memory.length) {
    list.innerHTML = '<div id="memory-empty">No memories saved yet.</div>';
    return;
  }
  memory.forEach((item, i) => {
    const div = document.createElement("div");
    div.className = "memory-item";
    div.innerHTML = `<span>${item}</span><button class="mem-del" data-i="${i}">×</button>`;
    list.appendChild(div);
  });
  list.querySelectorAll(".mem-del").forEach(btn => {
    btn.addEventListener("click", () => {
      memory.splice(parseInt(btn.dataset.i), 1);
      saveStorage();
      renderMemory();
    });
  });
}

document.getElementById("memory-save-btn").addEventListener("click", () => {
  const input = document.getElementById("memory-input");
  const val = input.value.trim();
  if (!val) return;
  memory.push(val);
  saveStorage();
  input.value = "";
  renderMemory();
  // switch to memory tab to confirm
  document.querySelector('[data-tab="memory"]').click();
});

document.getElementById("memory-input").addEventListener("keydown", e => {
  if (e.key === "Enter") document.getElementById("memory-save-btn").click();
});

// ── Settings view ─────────────────────────────────────────────────────────────
document.getElementById("save-key-btn").addEventListener("click", () => {
  const field  = document.getElementById("api-key-field");
  const status = document.getElementById("key-status");
  const key    = field.value.trim();
  if (key.startsWith("sk-ant-") || key.startsWith("sk-")) {
    apiKey = key;
    saveStorage();
    field.value = "••••••••••••" + key.slice(-4);
    status.textContent = "✓ Key saved";
    status.className = "key-status key-ok";
  } else {
    status.textContent = "✗ Invalid key format";
    status.className = "key-status key-bad";
  }
});

// ── Right-click context menu listener ────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "SELECTED_TEXT") {
    document.querySelector('[data-tab="chat"]').click();
    inputEl.value = `Explain this: "${msg.text}"`;
    inputEl.dispatchEvent(new Event("input"));
  }
});

// ── Init ──────────────────────────────────────────────────────────────────────
(async () => {
  await loadStorage();
  addMessage("jarvis", apiKey
    ? `Hello, sir. I have ${memory.length} memories loaded and I'm ready.\n\nIs there anything I can do for you?`
    : "Hello, sir. Please go to Settings and enter your API key to activate me."
  );
  if (apiKey) document.getElementById("status").style.background = "#00e5a0";
})();
